# -*- coding: utf-8 -*-
"""

DATA 608 - Story 2
Author: Glen Dale Davis
Start Date: September 19, 2023

"""

import datetime
from dotenv import load_dotenv
import json
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import os
import pandas as pd
import requests

load_dotenv()
bls_api_key = os.getenv("BLS_API_KEY")
fred_api_key = os.getenv("FRED_API_KEY")

# Function to retrieve BLS data for a data series adapted from:
# https://medium.com/@chris_42047/how-to-retrieve-the-consumer-price-index-python-tutorial-876f0e8c62ee
def fetch_bls_data(data_series_id, start_year, end_year):
    try:
        url = "https://api.bls.gov/publicAPI/v2/timeseries/data/"
        headers = {"Content-type": "application/json"}
        data = json.dumps({"registrationkey": bls_api_key,
                           "seriesid": [data_series_id],
                           "startyear": start_year,
                           "endyear": end_year})
        response = requests.post(url, data=data, headers=headers)
        if response.status_code != 200:
            raise Exception(f"Error retrieving data: {response.text}")
        json_data = json.loads(response.text)
        if json_data["status"] != "REQUEST_SUCCEEDED":
            raise Exception(f"Error retrieving data: {response.text}")
        results_df = pd.DataFrame()
        for series in json_data["Results"]["series"]:
            for item in series["data"]:
                year = int(item["year"])
                period = item["period"]
                value = float(item["value"])
                year_mon = f"{year}-{int(period.replace('M',''))}"
                date = datetime.datetime.strptime(year_mon, "%Y-%m")
                row_df = pd.DataFrame({"date": [date], "year": [year], "period": [period], "value": [value]})
                results_df = pd.concat([results_df, row_df], ignore_index=True)
        results_df = results_df.sort_values(by=["date"], ascending=False)
        results_df.set_index(["date"], inplace=True)
        return results_df
    except Exception as ex:
        print(f"Failed to fetch data: {ex}")

#Function to perform the above retrieval function in 5-year batches 5 times (so we wind up with 25 years of data)
def fetch_bls_in_cycles(data_series_id, csv):
    parts = range(1, 6)
    today = datetime.date.today()
    days_delta = datetime.timedelta(5 * 365)
    for p in parts:
        if p == 1:
            end_year_str = str(today.year)
            start_date = today - days_delta
            start_year_str = str(start_date.year)
            df = fetch_bls_data(data_series_id, start_year_str, end_year_str)
            ser = [data_series_id] * df.shape[0]
            df["series_id"] = ser
            df.to_csv(csv)
        else:
            end_year_str = str(start_date.year)
            start_date -= days_delta
            start_year_str = str(start_date.year)
            df = fetch_bls_data(data_series_id, start_year_str, end_year_str)
            ser = [data_series_id] * df.shape[0]
            df["series_id"] = ser
            df.to_csv(csv, mode="a", index=True, header=False)
    df = pd.read_csv(csv)
    df.sort_values(by="date", ascending=False, inplace=True)
    return df

#Function to retrieve FRED data observations for a data series
def fetch_fred_data(series_id, observ_start, observ_end, freq, agg):
    try:
        url = "https://api.stlouisfed.org/fred/series/observations"
        params = {"series_id": series_id,
                  "observation_start": observ_start,
                  "observation_end": observ_end,
                  "frequency": freq,
                  "aggregation_method": agg,
                  "api_key": fred_api_key,
                  "file_type": "json",
                  "sort_order": "desc",
                  "limit": 100000}
        response = requests.get(url, params=params)
        if response.status_code != 200:
            raise Exception(f"Error retrieving data.")
        response_df = pd.DataFrame(response.json()["observations"])[["date", "value"]]
    except Exception as ex:
        print(f"Failed to fetch data: {ex}")
    return response_df

# Consumer Price Index - All Urban Consumers - All Items - Create DF
if not os.path.isfile("cpi_df.csv"):
    cpi_df = fetch_bls_in_cycles("CUUR0000SA0", "cpi_df.csv")
    cpi_df.to_csv("cpi_df.csv", index=False)
else:
    cpi_df = pd.read_csv("cpi_df.csv")

# Local Area Unemployment Statistics - Unemployment Rate Only - States Only - Create DF
fn = "bls_gov_pub_time_series_la_la_area.txt"
st_codes = pd.read_csv(fn, sep="\t")
st_codes = st_codes.loc[st_codes["area_type_code"] == "A"]
keep = ["area_code", "area_text"]
st_codes = st_codes[keep]
remove = ["District of Columbia", "Puerto Rico"]
remove_bool = st_codes["area_text"].isin(remove)
st_codes = st_codes.loc[~remove_bool]
if os.path.isfile("completed_states.txt"):
    f = open("completed_states.txt", "r")
    completed_states = f.read().split("\n")
else:
    completed_states = []
if os.path.isfile("full_unemployment_df.csv"):
    full_unemployment_df = pd.read_csv("full_unemployment_df.csv")
    df_list = [v for k, v in full_unemployment_df.groupby("series_id")]
else:
    df_list = []
for code in st_codes.loc[:, "area_code"]:
    if code not in completed_states:
        data_series_id = "LAU" + code + "03"
        unemployment_df = fetch_bls_in_cycles(data_series_id, "unemployment_df.csv")
        df_list.append(unemployment_df)
        completed_states.append(code)
    else:
        next
    with open("completed_states.txt", "w") as f:
        f.write("\n".join(completed_states))
for i in range(len(df_list)):
    df = df_list[i]
    if i == 0:
        df.to_csv("full_unemployment_df.csv", index=False)
    else:
        df.to_csv("full_unemployment_df.csv", mode="a", index=False, header=False)

# Federal Funds Effective Rate - DFF - Create DF
if not os.path.isfile("fed_funds_rate_df.csv"):
    fed_funds_rate_df = fetch_fred_data("DFF", "1998-01-01", "2023-08-31", "m", "avg")
    fed_funds_rate_df["series_id"] = ["DFF"] * fed_funds_rate_df.shape[0]
    fed_funds_rate_df.to_csv("fed_funds_rate_df.csv", index=False)
else:
    fed_funds_rate_df = pd.read_csv("fed_funds_rate_df.csv")

#Combine data into one DF, delete duplicates
keep = ["date", "value"]
fed_funds_rate_df = fed_funds_rate_df[keep]
fed_funds_rate_df.rename(columns={"date":"date", "value":"DFF"},
                         inplace=True)
cpi_df.rename(columns={"date":"date", "year":"year",
                       "period":"period", "value":"CPI"},
              inplace=True)
cpi_df.drop_duplicates(inplace=True)
full_unemployment_df.drop_duplicates(inplace=True)
summarized_unemployment_df = full_unemployment_df.groupby(by=["year", "period"],
                                                          as_index=False).agg({"value": "mean"})
summarized_unemployment_df.rename(columns={"year":"year",
                                           "period":"period",
                                           "value":"LAUST-AVG"},
                                  inplace=True)
main_df = cpi_df.merge(fed_funds_rate_df, on="date", how="left",
                       indicator=False)
main_df = main_df.merge(summarized_unemployment_df, on=["year", "period"],
                        how="left", indicator=False)
main_df["date"] = pd.to_datetime(main_df["date"], format="%Y-%m-%d")
main_df.sort_values(by="date", ascending=True, inplace=True)
if not os.path.isfile("main_df.csv"):
    main_df.to_csv("main_df.csv", index=False)

#Visualize the data
main_df.set_index("date", inplace=True)
main_df["unit_change_CPI"] = main_df["CPI"].diff(periods=12)
main_df["percent_change_CPI"] = main_df["unit_change_CPI"].div(main_df["CPI"]) * 100
labels = {"percent_change_CPI":"YOY Change in Consumer Price Index (CPI)",
          "DFF":"Fed Funds Effective Rate",
          "LAUST-AVG":"Unemployment Rate"}
for col in ["percent_change_CPI", "DFF"]:
    label = labels[col]
    plt.plot(main_df.index, main_df[col], label=label)
plt.rcParams["figure.figsize"] = [12, 8]
plt.rcParams["figure.autolayout"] = True
plt.legend(bbox_to_anchor=(0, 1), loc='upper left')
plt.tight_layout()
plt.grid(visible=True, axis="y", linestyle=":", linewidth=2)
plt.xlabel("Year")
plt.ylabel("Percentage")
plt.title("Consumer Price Index & Fed Funds Effective Rate Over Time")
plt.text(datetime.datetime(2009, 7, 1), main_df.iloc[:, 6].dropna().min() - 0.3,
         "Great Recession Trough", rotation=0, color="black")
ax = plt.gca()
ax.set_ylim([-4, 14])
plt.show()
for col in ["LAUST-AVG", "DFF"]:
    label = labels[col]
    if col == "LAUST-AVG":
        color = "green"
    else:
        color = "orange"
    plt.plot(main_df.index, main_df[col], color=color, label=label)
plt.rcParams["figure.figsize"] = [12, 8]
plt.rcParams["figure.autolayout"] = True
plt.legend(bbox_to_anchor=(0, 1), loc='upper left')
plt.tight_layout()
plt.grid(visible=True, axis="y", linestyle=":", linewidth=2)
plt.xlabel("Year")
plt.ylabel("Percentage")
plt.title("Fed Funds Effective Rate & Unemployment Rate Over Time")
plt.text(datetime.datetime(2020, 4, 1), max(main_df["LAUST-AVG"]) + 0.2,
         "COVID-19 Peak", rotation=0, color="black")
ax = plt.gca()
ax.set_ylim([-4, 14])
plt.show()
